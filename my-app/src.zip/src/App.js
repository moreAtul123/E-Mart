import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import CategoryList from "./pages/CategoryList";
import ProductPage from "./pages/ProductPage";
import ProductDetails from "./pages/ProductDetails";
import SubcategoryPage from "./pages/SubcategoryPage";
import Orders from "./pages/Orders";
import OrderDetails from "./pages/OrderDetails";
import Profile from "./pages/Profile";
import Header from "./pages/Header"; // ✅ Import Header
import Footer from "./pages/Footer"; // ✅ Import Footer
import { AuthProvider } from "./AuthContext";
import { AuthContext } from "./AuthContext";  

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Routes without Header & Footer (Login, Register) */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Routes with Header & Footer */}
          <Route
            path="/*"
            element={
              <>
                <Header />
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/orders" element={<Orders />} />
                  <Route path="/order-details/:orderId" element={<OrderDetails />} />
                  
                  {/* Category Routes */}
                  <Route path="/categorylist" element={<CategoryList />} />
                  <Route path="/products/category/:categoryName" element={<CategoryList />} />
                  
                  {/* Product Routes */}
                  <Route path="/products/:id" element={<ProductPage />} />
                  <Route path="/product/:id/details" element={<ProductDetails />} />

                  {/* Subcategory & Additional Routes */}
                  <Route path="/subcategories/:categoryId" element={<SubcategoryPage />} />
                  <Route path="/products/subcategory/:subcategoryId" element={<ProductPage />} />
                </Routes>
                <Footer />
              </>
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
