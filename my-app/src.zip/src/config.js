// src/config.js
export const API_URL = "http://localhost:8080/api"; // Replace with your backend URL
