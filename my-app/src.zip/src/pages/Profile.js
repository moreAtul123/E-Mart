import React, { useEffect, useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/Profile.css"; // Add eMart logo

const Profile = () => {
  const userId = 4;
  const [userData, setUserData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!userId) return;
    const fetchUserProfile = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/users/${userId}`);
        setUserData(response.data);
        setError(null);
      } catch (err) {
        setError("Failed to fetch user profile");
        console.error(err);
      }
    };
    fetchUserProfile();
  }, [userId]);

  return (
    <div className="profile-container">
      <div className="profile-card">
        <h2 className="profile-title">User Profile</h2>
        {error ? (
          <p className="error-text">{error}</p>
        ) : userData ? (
          <ul className="profile-list">
            <li><strong>User ID:</strong> {userData.userId}</li>
            <li><strong>Name:</strong> {userData.name}</li>
            <li><strong>Email:</strong> {userData.email}</li>
            <li><strong>Mobile:</strong> {userData.mobileNumber}</li>
            <li><strong>Address:</strong> {userData.address || "N/A"}</li>
            <li><strong>Membership:</strong> {userData.member ? "Active" : "Inactive"}</li>
          </ul>
        ) : (
          <p className="loading-text">Loading...</p>
        )}
      </div>
    </div>
  );
};

export default Profile;
