import { useState } from "react";
import { registerUser } from "../api";
import { useNavigate } from "react-router-dom";
import "../styles/register.css";

const Register = () => {
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    mobileNumber: "",
    password: "",
    address: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    let newErrors = {};
    if (userData.name.length < 3 || userData.name.length > 30) {
      newErrors.name = "Name must be between 3 and 30 characters";
    }
    if (!/^\S+@\S+\.\S+$/.test(userData.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!/^\d{10}$/.test(userData.mobileNumber)) {
      newErrors.mobileNumber = "Mobile number must be exactly 10 digits";
    }
    if (userData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters long";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      await registerUser(userData);
      document.getElementById("success-message").classList.add("show");
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    } catch (error) {
      alert("Registration Failed!");
    }
  };

  return (
    <div className="register-container">
      <div className="register-box">
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSF8ExH1zQPwZ4z3pa4gdCl76l9eJ4T7Ai8iw&s"
          alt="eMart Logo"
          className="register-logo"
        />
        <h2 className="create-account">Create Account</h2>
        <form className="register-form" onSubmit={handleSubmit}>
          <input type="text" name="name" placeholder="Name" onChange={handleChange} required />
          {errors.name && <p className="error-message">{errors.name}</p>}

          <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
          {errors.email && <p className="error-message">{errors.email}</p>}

          <input type="text" name="mobileNumber" placeholder="Mobile Number" onChange={handleChange} required />
          {errors.mobileNumber && <p className="error-message">{errors.mobileNumber}</p>}

          <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
          {errors.password && <p className="error-message">{errors.password}</p>}

          <textarea name="address" placeholder="Address" onChange={handleChange}></textarea>

          <button type="submit" className="register-btn">Register</button>
          <button type="button" className="register-btn secondary" onClick={() => navigate("/login")}>
            Login
          </button>
        </form>
      </div>

      <div id="success-message" className="success-message">
        Registration Successful!...
      </div>
    </div>
  );
};

export default Register;
