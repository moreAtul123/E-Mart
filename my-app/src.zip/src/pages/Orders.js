import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/Orders.css";

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const orderIds = [2]; // Example Order IDs (Replace dynamically)
  const navigate = useNavigate();

  useEffect(() => {
    console.log("Fetching orders for order IDs:", orderIds);

    const fetchOrders = async () => {
      try {
        const fetchedOrders = await Promise.all(
          orderIds.map(async (orderId) => {
            console.log(`Fetching order with ID: ${orderId}`);
            const response = await axios.get(`http://localhost:8080/api/orders/${orderId}`);
            console.log(`Response for Order ${orderId}:`, response.data);
            return response.data;
          })
        );

        setOrders(fetchedOrders.filter(Boolean)); // Filter out empty/null responses
      } catch (error) {
        console.error("Error fetching orders:", error);
        setOrders([]);
      }
    };

    fetchOrders();
  }, []);

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Your Orders</h2>

      {orders.length === 0 ? (
        <p className="text-center">No orders found.</p>
      ) : (
        <ul className="order-list">
          {orders.map((order) => (
            <li key={order.orderId} className="order-item">
              <span>Order ID: #{order.orderId}</span>
              <span>Date: {new Date(order.orderDate).toLocaleString()}</span>
              <span>Total: ${order.totalAmount.toFixed(2)}</span>
              <button
                className="btn btn-primary btn-sm"
                onClick={() => navigate(`/order-details/${order.orderId}`)}
              >
                View Details
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Orders;
