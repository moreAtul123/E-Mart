import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import "../styles/subcategoryPage.css";  // Import CSS

const SubcategoryPage = () => {
  const { categoryId } = useParams();
  const [subcategories, setSubcategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSubcategoriesByCategory = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/api/subcategories/category/${categoryId}`
        );
        setSubcategories(response.data);
      } catch (err) {
        setError("Error fetching subcategories");
      } finally {
        setLoading(false);
      }
    };

    fetchSubcategoriesByCategory();
  }, [categoryId]);

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="subcategory-container">
      <h2>Subcategories for Category {categoryId}</h2>
      <div className="subcategory-grid">
        {subcategories.map((subcategory) => (
          <Link
            key={subcategory.subcategoryId}
            to={`/api/subsubcategories`}
            className="subcategory-card"
          >
           <img
  src={subcategory.imageUrl || "https://media.gettyimages.com/id/1293762741/photo/modern-living-room-interior-3d-render.jpg?s=612x612&w=gi&k=20&c=6cE9Zg6kGSXOs9WrwCNG-3zXMyLkr1Y1_DH7qg_z-iY="}
  alt={subcategory.subcategoryName}
/>

            <h3>{subcategory.subcategoryName}</h3>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default SubcategoryPage;
