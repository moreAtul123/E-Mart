import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/SubSubcategories.css"; // Import CSS
import "bootstrap/dist/css/bootstrap.min.css";

const SubSubcategories = () => {
  const [subSubcategories, setSubSubcategories] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/subsubcategories") // Adjust API URL if needed
      .then((response) => {
        setSubSubcategories(response.data);
      })
      .catch((error) => {
        console.error("Error fetching sub-subcategories:", error);
      });
  }, []);

  return (
    <div className="container">
      <h2 className="text-center my-4">Sub-Subcategories</h2>
      <div className="row">
        {subSubcategories.map((product) => (
          <div key={product.id} className="col-md-4 col-sm-6 mb-4">
            <div className="product-card">
              <img src={product.imageUrl} alt={product.name} className="product-image" />
              <div className="product-info">
                <h4>{product.name}</h4>
                <p>{product.description}</p>
                <p className="price">₹{product.price}</p>
                <button className="btn btn-primary">Buy Now</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubSubcategories;
