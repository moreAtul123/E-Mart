import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "../styles/CategoryList.css";

const CategoryList = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/categories");
        setCategories(response.data);
      } catch (err) {
        setError("Error fetching categories");
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="category-container">
      <h2 className="category-title">Shop by Categories</h2>
      <div className="category-grid">
        {categories.map((category) => (
          <div className="category-card" key={category.categoryId}>
            <Link to={`/subcategories/${category.categoryId}`}>
  <img
    src={category.imageUrl || "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIPZyhZKzBsMn3nZ6LWffwDu8NfTsWgx1qrw&s"}
    alt={category.categoryName}
  />
  <h3>{category.categoryName}</h3>
</Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryList;
