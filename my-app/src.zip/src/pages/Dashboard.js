import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Carousel } from "react-bootstrap";
import Header from "./Header";
import "../styles/Dashboard.css";

const Dashboard = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  }, []);

  return (
    <div>
      {isLoading && (
        <div className="preloader">
          <div className="spinner"></div>
        </div>
      )}

      <Header />

      {/* Hero Section with Flipkart-Style Carousel */}
      <div className="hero-section">
        <Carousel controls={true} indicators={true} interval={3000} pause={false} fade>
          <Carousel.Item>
            <img
              src="https://media.istockphoto.com/id/1292443598/photo/flying-shopping-cart-with-shopping-bags-on-a-pink-background.jpg?s=612x612&w=0&k=20&c=sMJy_CYmuKtwXE8LCPI9lkyWEgB1lKfhuJg8hF48LyA="
              className="d-block w-100"
              alt="Shopping Banner 1"
            />
            <Carousel.Caption>
              <h3>Exclusive Deals on Electronics</h3>
              <p>Grab the latest gadgets at unbeatable prices!</p>
              <a href="http://localhost:3000/subcategories/1" className="btn btn-warning">Shop Now</a>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              src="https://images.unsplash.com/photo-1540221652346-e5dd6b50f3e7?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2xvdGhlc3xlbnwwfHwwfHx8MA%3D%3Dhttps://images.unsplash.com/photo-1540221652346-e5dd6b50f3e7?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2xvdGhlc3xlbnwwfHwwfHx8MA%3D%3D"
              className="d-block w-100"
              alt="Shopping Banner 2"
            />

<Carousel.Caption>
              <h3>Exclusive Deals on Electronics</h3>
              <p>Grab the latest gadgets at unbeatable prices!</p>
              <a href="http://localhost:3000/subcategories/1" className="btn btn-warning">Shop Now</a>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              src="https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGVsZWN0cm9uaWNzfGVufDB8fDB8fHww"
              className="d-block w-100"
              alt="Shopping Banner 3"
            />
            
            <Carousel.Caption>
              <h3>FlashSale - Up to 70% Off</h3>
              <p>Upgrade your wardrobe with trending styles.</p>
              <a href="http://localhost:3000/subcategories/2" className="btn btn-primary">Shop Now</a>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
            <img
              src="https://imgs.search.brave.com/rrKzTYbAUU2b4dswK28R2SzMUK8lCYIarNEv_gGAaBE/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5pc3RvY2twaG90/by5jb20vaWQvNTEz/NDM5MzQxL3Bob3Rv/L3BvcnRyYWl0LW9m/LWVudGh1c2lhc3Rp/Yy1idXNpbmVzcy1w/ZW9wbGUtaW4tY2ly/Y2xlLmpwZz9zPTYx/Mng2MTImdz0wJms9/MjAmYz1veHdzcThX/R0ZUMGl4bVNvam50/WUJFWnFpZm5lNFA3/RGxxT1diWENxV1Vr/PQ"
              className="d-block w-100"
              alt="Shopping Banner 4"
            />
            
            <Carousel.Caption>
              <h3>Best Offers of 2025</h3>
              <p>Find the perfect products for you at the best price.</p>
              <a href="/CategoryList" className="btn btn-success">Shop Now</a>
            </Carousel.Caption>
          </Carousel.Item>
          
        </Carousel>
      </div>

      {/* Welcome Section */}
      <div className="container my-5 text-center">
        <h2>Welcome to E-Mart</h2>
        <p>Discover the latest trends in fashion, electronics, and more!</p>
        <a href="/productpage" className="btn btn-primary btn-lg">
          Start Shopping
        </a>
      </div>
    </div>
  );
};

export default Dashboard;
